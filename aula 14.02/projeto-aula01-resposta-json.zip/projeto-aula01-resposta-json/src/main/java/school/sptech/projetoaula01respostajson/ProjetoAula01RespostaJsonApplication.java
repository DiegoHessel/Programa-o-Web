package school.sptech.projetoaula01respostajson;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoAula01RespostaJsonApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoAula01RespostaJsonApplication.class, args);
	}

}
