package school.sptech.projetoaula01respostajson;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoAula01RespostaJsonApplicationTests {

	@Test
	void contextLoads() {
	}

}
