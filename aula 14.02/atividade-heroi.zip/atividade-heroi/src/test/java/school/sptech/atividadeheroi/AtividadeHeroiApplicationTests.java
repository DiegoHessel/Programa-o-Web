package school.sptech.atividadeheroi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtividadeHeroiApplicationTests {

	@Test
	void contextLoads() {
	}

}
