package school.sptech.atividadeheroi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtividadeHeroiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtividadeHeroiApplication.class, args);
	}

}
