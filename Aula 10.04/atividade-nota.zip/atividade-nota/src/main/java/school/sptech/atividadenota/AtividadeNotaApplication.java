package school.sptech.atividadenota;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtividadeNotaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtividadeNotaApplication.class, args);
	}

}
