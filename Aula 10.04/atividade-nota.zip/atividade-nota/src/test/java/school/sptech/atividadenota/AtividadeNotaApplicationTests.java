package school.sptech.atividadenota;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtividadeNotaApplicationTests {

	@Test
	void contextLoads() {
	}

}
