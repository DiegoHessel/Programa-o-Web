package school.sptech.exercicio;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/carros")
public class CarroController {
    private List<Carro> carros = new ArrayList<>();
    private int id;
    @GetMapping
    public ResponseEntity<List<Carro>> listarCarros() {
        if (carros.isEmpty()) {
            return ResponseEntity.status(204).body(carros);
        }
        return ResponseEntity.status(200).body(carros);
    }

    @PostMapping
    public ResponseEntity<Carro> cadastrar(@RequestBody Carro novoCarro) {
        if (!placaValida(novoCarro.getPlaca())) {
            return ResponseEntity.status(400).build();
        }
        if (palcaExiste(novoCarro.getPlaca())) {
            return ResponseEntity.status(409).build();
        }
        novoCarro.setId(id++);
        carros.add(novoCarro);

        return ResponseEntity.status(201).body(novoCarro);
    }
private boolean placaValida(String placa) {
        return placa.matches("[A-Z]{3}[0-9]{4}");
    }
    private boolean palcaExiste (String placa){
        for (Carro carro : carros) {
            if (carro.getPlaca().equals(placa)) {
                return true;
            }
        }
        return false;
    }
    @GetMapping("/{id}")
    public ResponseEntity<Carro> buscarPorId(@PathVariable int id) {
        for (Carro carro : carros) {
            if (carro.getId() == id) {

                return ResponseEntity.status(200).body(carro);
            }
        }
        return ResponseEntity.status(404).build();
    }


    @PutMapping("/{id}")
    public ResponseEntity<Carro> atualizar(@PathVariable int id, @RequestBody Carro carro) {
        for (Carro carro1 : carros) {
            if (carro1.getId() == id) {
                carro1.setMarca(carro.getMarca());
                carro1.setModelo(carro.getModelo());
                carro1.setCor(carro.getCor());
                carro1.setPlaca(carro.getPlaca());
                carro1.setPreco(carro.getPreco());
                carro1.setAno(carro.getAno());
                return ResponseEntity.status(200).body(carro1);
            }
        }
        return ResponseEntity.status(404).build();
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable int id) {
        for (Carro carro : carros) {
            if (carro.getId() == id) {
                carros.remove(carro);
                return ResponseEntity.status(204).build();
            }
        }
        return ResponseEntity.status(404).build();
    }
    @PatchMapping({"/{id}","emplacamento", "/placa"})
    public ResponseEntity<Carro> atualizarPreco(@RequestBody Carro carro) {
        for (Carro carro1 : carros) {
            if (carro1.getPlaca().equals(carro.getPlaca())) {
                carro1.setPreco(carro.getPreco());
                return ResponseEntity.status(200).body(carro1);
            }
        }
        return ResponseEntity.status(404).build();
    }

    @GetMapping("/busca-por-marca")
    public ResponseEntity<List<Carro>> buscarPorMarca(@RequestParam String marca) {
        List<Carro> carrosEncontrados = new ArrayList<>();
        for (Carro carro : carros) {
            if (carro.getMarca().equals(marca)) {
                carrosEncontrados.add(carro);
            }
        }
        if (carrosEncontrados.isEmpty()) {
            return ResponseEntity.status(204).body(carrosEncontrados);
        }
        return ResponseEntity.status(200).body(carrosEncontrados);
    }
    private double somarPreco() {
        double preco = 0;
        for (Carro carro : carros) {
            preco += carro.getPreco();
        }
        return preco;
    }
private double mediaPreco() {
        return somarPreco() / carros.size();
    }
    @GetMapping("/media-preco")
    public ResponseEntity<Double> mediaPrecoCarros() {
        if (carros.isEmpty()) {
            return ResponseEntity.status(204).build();
        }
        return ResponseEntity.status(200).body(mediaPreco());
    }
}