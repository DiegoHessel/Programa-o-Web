package school.sptech.atividaderelacionamento.dto.tarefa;

import school.sptech.atividaderelacionamento.dto.projeto.ProjetoListagemDto;
import school.sptech.atividaderelacionamento.entity.tarefa.Tarefa;

import java.util.List;

public class TarefaMapper {

    public static TarefaListagemDto toDto(Tarefa entity) {
        return null;
    }

    public static List<ProjetoListagemDto.TarefaListagemDto> toDto(List<Tarefa> entities) {
        return null;
    }

    public static Tarefa toEntity(TarefaCriacaoDto dto) {
        return null;
    }
}
