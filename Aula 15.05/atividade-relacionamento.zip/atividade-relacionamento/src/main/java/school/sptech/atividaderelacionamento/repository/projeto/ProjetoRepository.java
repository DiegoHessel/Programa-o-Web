package school.sptech.atividaderelacionamento.repository.projeto;

import org.springframework.data.jpa.repository.JpaRepository;
import school.sptech.atividaderelacionamento.entity.projeto.Projeto;

public interface ProjetoRepository extends JpaRepository<Projeto, Integer>{
}
