package school.sptech.atividaderelacionamento.exception;

public class EntidadeNaoEncontradaException extends RuntimeException {

}
