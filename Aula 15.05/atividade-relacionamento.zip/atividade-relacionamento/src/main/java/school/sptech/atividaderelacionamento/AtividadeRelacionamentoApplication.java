package school.sptech.atividaderelacionamento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtividadeRelacionamentoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtividadeRelacionamentoApplication.class, args);
	}

}
