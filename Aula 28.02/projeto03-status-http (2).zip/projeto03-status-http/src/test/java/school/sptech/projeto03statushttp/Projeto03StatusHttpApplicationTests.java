package school.sptech.projeto03statushttp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projeto03StatusHttpApplicationTests {

	@Test
	void contextLoads() {
	}

}
