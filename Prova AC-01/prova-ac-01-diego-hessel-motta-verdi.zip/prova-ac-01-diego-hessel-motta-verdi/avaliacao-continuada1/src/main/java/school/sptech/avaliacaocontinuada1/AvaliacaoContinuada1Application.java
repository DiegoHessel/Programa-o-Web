package school.sptech.avaliacaocontinuada1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AvaliacaoContinuada1Application {

	public static void main(String[] args) {
		SpringApplication.run(AvaliacaoContinuada1Application.class, args);
	}
}
